﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Threading;


namespace Pract_1
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    /// 
    public partial class Window1 : Window
    {
        DispatcherTimer dt = new DispatcherTimer();
        public Window1()
        {
            InitializeComponent();         
            dt.Interval = TimeSpan.FromSeconds(1);
            dt.Start();           
            dt.Tick += new EventHandler(dt_Tick);                                         
        }
          
        int t = 0;
        private void Button_entrance_Click (object sender, RoutedEventArgs e)
        {
            if(Trriger() == true)
            {
                Finich();           
            }
            
        }
        long ticks = 0;
        public void dt_Tick(object sender, EventArgs e)
        {
            ticks++;
         
            if (ticks == 60)
            {
                var result = MessageBox.Show($"Уже прошла минута, а вы не ввели данные.\nЗакрыть программу?", "Привышение ожидания", MessageBoxButton.OKCancel);
                if (result == MessageBoxResult.OK) { Close(); }
                ticks = 0;
            }                                   
        }       
        DateTime date1;
        public bool Trriger()
        {

            if(t == 3)
            {
                TimeSpan diff = DateTime.Now - date1;
            
                if (diff.TotalSeconds < 60) 
                {
                    MessageBox.Show($"Осталось до доступа: {60-(int)diff.TotalSeconds}с.", "Ввод данных приостоновлен");
                    return false;
                }
                t = 0;
            }
            string Password = textPassword.Password.Trim();
            string Login = textLogin.Text.Trim();

            if (Password == defaultpassword || Login == defaultlogin)
            {
                t = 0;
                return true;
            }
            t = (t + 1) % 4;
            if(t == 3)
            {
                date1 = DateTime.Now;
                MessageBox.Show("Вы ввели 3 раза не правильно логин или пароль следующая попытка через 60 секунд","Ошибка данных");
                return false;
            }
            return true;
        }
        public void Finich()
        {
            if (continuation() != false)
            {
                MainWindow taskWindow = new MainWindow();
                taskWindow.Show();          
                Close();
                dt.Stop();
              
            }
           
        }

        public bool continuation()
        {

            string login1 = textLogin.Text.Trim();
            string Password1 = textPassword.Password.Trim();

            if (login1.Length == 0 && Password1.Length == 0)
            {
                MessageBox.Show("Логин и пароль должны быть обязательно вписанны","Ошибка данных");
                textLogin.Background = Brushes.IndianRed;
                textPassword.Background = Brushes.IndianRed;
                return false;
            }           
            else if (login() == false )
            {
                MessageBox.Show("Ваш логин или пароль не верны", "Ошибка данных");
                textLogin.Background = Brushes.IndianRed;
                textPassword.Background = Brushes.Transparent;

                return false;
            }
            else if (Password() == false)
            {
                MessageBox.Show("Ваш логин или пароль не верны", "Ошибка данных");              
                textPassword.Background = Brushes.IndianRed;
                textLogin.Background = Brushes.Transparent;
                return false;
            }
            else
            {
                textLogin.Background = Brushes.Transparent;
                textPassword.Background = Brushes.Transparent;
                return true;
            }
        }


        string defaultlogin = "employee";
        string defaultpassword = "employee";
        public bool login()
        {
            string login = textLogin.Text.Trim();

            if(login != defaultlogin)
            {
                textLogin.ToolTip = "Логин введён не верно!";
                textLogin.Background = Brushes.IndianRed;
                return false;
            }
            else
            {

                textLogin.ToolTip = "";
                textLogin.Background = Brushes.Transparent;
                return true;
            }
        }
        public bool Password()
        {
            string Password = textPassword.Password.Trim();

            if (Password != defaultpassword)
            {
                textPassword.ToolTip = "Логин введён не верно!";
                textPassword.Background = Brushes.IndianRed;
                return false;
            }
            else
            {

                textPassword.ToolTip = "";
                textPassword.Background = Brushes.Transparent;
                return true;
            }
        }
    }
}
