﻿using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;


namespace Pract_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string employee = "C:/Users/Pc/Desktop/employee.txt";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_add_Click(object sender, RoutedEventArgs e)
        {
            File_();
        }
        public void File_()
        {
            if (ID_() == true && Surname() == true && Name_() == true && Middl_name() == true && Passport() == true && Telehpon() == true && Email() == true)
            {

                MessageBox.Show("Всё коректно, ваши данные добавлены!", "Data base");
                AddFile();
            }
            else
            {
                MessageBox.Show("Что-то пошло не так, пожалуйста попробуйте снова ", "Ошибка данных");
            }
        }

        public void AddFile()
        {
            File.AppendAllText(employee,
                   $"{textID.Text.Trim()}\t" +
                   $"{textSurname.Text.Trim()}\t" +
                   $"{textName.Text.Trim()}\t" +
                   $"{textMiddle_name.Text.Trim()}\t" +
                   $"{textPassport.Text.Trim()}\t" +
                   $"{textTelephone.Text.Trim()}\t" +
                   $"{textEmail.Text.Trim()}\n");
            textID.Clear();
            textSurname.Clear();
            textName.Clear();
            textMiddle_name.Clear();
            textPassport.Clear();
            textTelephone.Clear();
            textEmail.Clear();
        }
        public bool ID_()
        {
            string id = textID.Text.Trim();
            string[] file = new string[] { };
            bool flag = true;
            file = File.ReadAllLines(employee);
            foreach (string line in file)
                if (line.Split()[0] == id)
                {
                    flag = false;
                }
            if (id.Length == 0 || flag == false || !Regex.IsMatch(id, "^[0-9]+$"))
            {
                textID.ToolTip = "Такой идентификатор уже присутствует, поле пустое или присутствуют символы кроме цифр";
                textID.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textID.ToolTip = "";
                textID.Background = Brushes.Transparent;
                return true;
            }
        }
        public bool Telehpon()
        {
            string Telephone = textTelephone.Text.Trim();
            if (((Telephone.Length != 12 || Telephone[0] != '+' || Telephone[1] != '7' || !Regex.IsMatch(Telephone, "^[+][0-9]+$")) &&
                 (Telephone.Length != 11 || Telephone[0] != '8' || !Regex.IsMatch(Telephone, "^[0-9]+$"))))
            {
                textTelephone.ToolTip = "Номер введён не коректно";
                textTelephone.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textTelephone.ToolTip = "";
                textTelephone.Background = Brushes.Transparent;
                return true;
            }
        }
        public bool Email()
        {
            string Email = textEmail.Text.Trim();
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,5})+)$");
            Match match = regex.Match(Email);
            if (!match.Success || Regex.IsMatch(Email, "[а-я]") || Regex.IsMatch(Email, "[А-Я]"))
            {
                textEmail.ToolTip = "Почта введена не верно";
                textEmail.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textEmail.ToolTip = "";
                textEmail.Background = Brushes.Transparent;
                return true;
            }
        }
        public bool Passport()
        {
            string Passport = textPassport.Text.Trim();
            if (!Regex.IsMatch(Passport, "^[0-9]+$") || Passport.Length != 10)
            {
                textPassport.ToolTip = "Паспорт введён не верно";
                textPassport.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textPassport.ToolTip = "";
                textPassport.Background = Brushes.Transparent;
                return true;
            }
        }
        //наш метод проверки
        public bool Name_()
        {
            // Введённую строку копираю из textbox в пременную Name типа string
            string Name = textName.Text.Trim();
            // Проверяю пуста ли длина или нет совпадения с регулярным выражением
            if (Name.Length == 0 || !Regex.IsMatch(Name, "^[А-ЯЁ][а-я]+${2,24}"))
            {
                // Если не прошло проверку
                // Для пользователя выводим всплывающееся окошко с подсказкой
                textName.ToolTip = "Имя должно быть введено кирилицей и начинаться с большой буквы";
                // textbox окрашиваем в красный цвет
                textName.Background = Brushes.IndianRed;
                // Возращаем false
                return false;
            }
            else
            {
                // Если прошло проверку
                // Для пользователя убирается всплывающееся окошко с подсказкой
                textName.ToolTip = "";
                // textbox окрашиваем в прозрачный
                textName.Background = Brushes.Transparent;
                // Возращаем true
                return true;
            }

        }
        public bool Surname()
        {
            string Surname = textSurname.Text.Trim();
            if (Surname.Length == 0 ||  !Regex.IsMatch(Surname, "^[А-ЯЁ][а-я]+${4,24}"))
            {
                textSurname.ToolTip = "Фамилия должна быть введена кирилицей и начинаться с большой буквы";
                textSurname.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textSurname.ToolTip = "";
                textSurname.Background = Brushes.Transparent;
                return true;
            }
        }
        public bool Middl_name()
        {

            string Middl_name = textMiddle_name.Text.Trim();
            if (Middl_name.Length == 0 || !Regex.IsMatch(Middl_name, "^[А-ЯЁ][а-я]+${4,24}"))
            {
                textMiddle_name.ToolTip = "Отчество должно быть ввидено кирилицей и начинаться с большой буквы";
                textMiddle_name.Background = Brushes.IndianRed;
                return false;
            }
            else
            {
                textMiddle_name.ToolTip = "";
                textMiddle_name.Background = Brushes.Transparent;
                return true;
            }

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 WindowStart = new Window1();
            WindowStart.Show();
            Close();
        }
    }
}
