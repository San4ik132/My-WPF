﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;


namespace WpfApp5
{
    public partial class MainWindow : Window
    {
        string adres = @"C:\Users\student\Documents\employee.txt";

        public MainWindow() => InitializeComponent();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (CheckAll())
                FileAdd();
            else
                MessageBox.Show("Ошибка", "Проверьте введённые данные ", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        private bool CheckAll()
        {
            return (CheckId(IdBox.Text) && СheckName(NameBox.Text) && СheckName(SurnameBox.Text) && СheckName(DadBox.Text) && СheckNumber(NumberBox.Text) && CheckMail(MailBox.Text) && CheckPasport(PasportBox.Text));
        }
        private bool CheckId(string Id)
        {

            if (Regex.IsMatch(Id, "^[0-9+]+$"))
                return true;
            return false;
        }
        private bool СheckName(string Fio)
        {
            return (Fio[0] == Char.ToUpper(Fio[0]) && Regex.IsMatch(Fio.ToLower(), @"[а-я]$"));
        }
        private bool СheckNumber(string Number)
        {
            return (((Number[0] == '+') && (Number[1] == '7') &&
                (Number.Length == 12)) || ((Number[0] == '8') && (Number.Length == 11)) &&
                !Number.Any(Char.IsLetter));
        }
        private bool CheckPasport(string Pasport)
        {
            if (Pasport.Length != 10 || Regex.Match(Pasport, "[А-Яа-яЁё]" + "[A-Za-z]").Success || Pasport.Intersect(@"<>()[]!,;:\ /*").Count() > 0)
                return false; 
            return true;
        }
        private bool CheckMail(string Mail)
        {
            Regex regex = new Regex(@"^[A-Z]([\w.-]+)@([\w-]+)((.(\w){2,5})+)$");
            Match match = regex.Match(Mail);
            if (!match.Success)
                return true;
            else
                return false;


        }
        private void FileAdd()
        {
            if (NewId(IdBox.Text))
                try
                {
                    File.AppendAllText(adres, 
                        "Идентификатор: " + IdBox.Text + "\t" +
                        "Фамилия: " + SurnameBox.Text + "\t" + 
                        "Имя: " + NameBox.Text + "\t" +
                        "Отчество: " + DadBox.Text + "\t" +
                        "Телефон: " + NumberBox.Text + "\t" +
                        "Паспорт: " + PasportBox.Text + "\t" +
                        "Почта: " + MailBox.Text + "\n");
                    ClearAllBoxes();
                    MessageBox.Show("Выполнено! ", "OK", MessageBoxButton.OK);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }
        private bool NewId(string index)
        {
            string[] employeFileContent = new string[] { };

            try
            {
                if (!File.Exists(adres))
                    return true;

                employeFileContent = File.ReadAllLines(adres);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            foreach (string line in employeFileContent)
                if (line.Split()[1] == index)
                {
                    MessageBox.Show("Employee with this ID is already registred!");
                    return false;
                }
            return true;
        }
        private void ClearAllBoxes()
        {
            IdBox.Text = "";
            SurnameBox.Text = "";
            NameBox.Text = "";
            DadBox.Text = "";
            NumberBox.Text = "";
            PasportBox.Text = "";
            MailBox.Text = "";
        }
    }
}
